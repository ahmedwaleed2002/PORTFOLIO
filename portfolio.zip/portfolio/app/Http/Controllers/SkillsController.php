<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class SkillsController extends Controller
{
    public function index()
    {
        $skills = ['HTML', 'CSS', 'JavaScript', 'PHP', 'Laravel', 'MySQL'];

        return view('skills', compact('skills'));
    }
}