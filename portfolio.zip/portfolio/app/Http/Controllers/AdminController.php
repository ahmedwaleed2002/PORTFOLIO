<?php

namespace App\Http\Controllers;

use App\Models\Record;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class AdminController extends Controller
{
    public function index()
    {
        // Check if the user is logged in
        if (!Auth::guard()->check()) {
            return redirect()->route('login');
        }
    
        // Get the records from the database
        $records = \App\Http\Controllers\CrudController::readRecords();
    
        return view('admin', compact('records'));
    }
}