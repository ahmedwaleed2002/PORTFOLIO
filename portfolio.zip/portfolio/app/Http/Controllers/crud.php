<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Record; // Assuming your model is named 'Record'

class CrudController extends Controller
{
    // Create a new record
    public function create(Request $request) {
        // Validate request data
        $validatedData = $request->validate([
            'name' => 'required',
            'email' => 'required|email',
            'message' => 'required',
        ]);

        // Create the record
        Record::create($validatedData);

        // Redirect or return a response
    }

    // Read all records
    public function read() {
        $records = Record::all();
        return $records;
    }

    // Update a record
    public function update(Request $request, $id) {
        // Validate request data
        $validatedData = $request->validate([
            'name' => 'required',
            'email' => 'required|email',
            'message' => 'required',
        ]);

        // Find the record by id and update
        $record = Record::findOrFail($id);
        $record->update($validatedData);

        // Redirect or return a response
    }

    // Delete a record
    public function delete($id) {
        // Find the record by id and delete
        $record = Record::findOrFail($id);
        $record->delete();

        // Redirect or return a response
    }
}
