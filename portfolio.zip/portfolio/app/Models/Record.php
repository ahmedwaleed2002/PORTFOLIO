<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Record extends Model
{
    protected $fillable = ['name', 'email', 'message'];

    // Additional model logic, such as relationships or custom methods, can be added here
}
