@extends('index')

@section('content')
<section id="skills">
    <h2>My Skills</h2>
    <ul>
        @foreach($skills as $skill)
            <li>{{ $skill }}</li>
        @endforeach
    </ul>
    <p><a href="{{ route('home') }}">Go back to the homepage</a></p>
    <p><a href="{{ route('projects') }}">Check out my projects</a></p>
    <p><a href="{{ route('contact') }}">Get in touch</a></p>
</section>
@endsection
