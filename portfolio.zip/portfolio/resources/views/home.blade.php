@extends('index')

@section('content')
    <section id="home">
        <h2>Ahmed Waleed Bin Yunus</h2>
        <p>I am a software engineering student at the University of Lahore (UOL). I am passionate about developing innovative and user-friendly applications that can solve real-world problems. i have experience in working with various programming languages and frameworks, such as Java, Python, C#, .NET, and React. I am also intrested in artificial intelligence, blockchain, and cloud computing. My goal is to become a successful software engineer who can contribute to the advancement of the software industry and society.
      </p>
        <p><a href="{{ route('skills') }}">Learn more about my skills</a></p>
        <p><a href="{{ route('projects') }}">Check out my projects</a></p>
        <p><a href="{{ route('contact') }}">Get in touch</a></p>
    </section>
@endsection
