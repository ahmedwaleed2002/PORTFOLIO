@extends('index')

@section('content')
  <section id="contact">
    <h2>Contact Me</h2>
    <p>Email: ahmedwaleed@example.com</p>
    <p>GitHub: github.com/ahmedwaleed</p>

    <div>
      <h3>Create New Contact</h3>
      <form action="{{ route('contacts.store') }}" method="post">
        @csrf
        <label for="name">Name:</label>
        <input type="text" id="name" name="name" required><br>

        <label for="email">Email:</label>
        <input type="email" id="email" name="email" required><br>

        <label for="message">Message:</label>
        <textarea id="message" name="message" rows="5" cols="30" required></textarea><br>

        <input type="submit" value="Create Contact">
      </form>
    </div>

    <div>
      <h3>Contacts</h3>
      <ul style="list-style-type: none; padding-left: 0;">
        @foreach($contacts as $contact)
          <li style="display: flex; justify-content: space-between; align-items: center; padding: 15px 10px; border-bottom: 1px solid #ccc;">
            <span style="flex-grow: 1;">
              <span style="display: block; margin-bottom: 5px;">{{ $contact->name }} - {{ $contact->email }}</span>
              <span style="display: block;">{{ $contact->message }}</span>
            </span>
            <div style="display: flex; gap: 10px;">
              <a href="{{ route('contacts.edit', $contact->id) }}" style="padding: 10px 15px; background-color: #333; color: #fff; text-decoration: none; width: 60px; text-align: center;">Edit</a>
              <form action="{{ route('contacts.destroy', $contact->id) }}" method="post" style="display: flex;">
                @csrf
                @method('DELETE')
                <button type="submit" style="background-color: transparent; border: none; color: #333; cursor: pointer; width: 60px; text-align: center;">Delete</button>
              </form>
            </div>
          </li>
        @endforeach
      </ul>
    </div>

    <p><a href="{{ route('home') }}">Go back to the homepage</a></p>
    <p><a href="{{ route('skills') }}">Learn more about my skills</a></p>
    <p><a href="{{ route('projects') }}">Check out my projects</a></p>
  </section>
@endsection

<style>
  /* Style adjustments for improved layout */
  .contact-list li {
    display: flex; /* Use flexbox for better alignment */
    justify-content: space-between; /* Distribute elements horizontally */
    align-items: center; /* Align vertically */
    padding: 15px 10px; /* Increase padding for better spacing */
    border-bottom: 1px solid #ccc;
  }

  .contact-list li span {
    flex-grow: 1; /* Allow content to fill remaining space */
  }

  .contact-list li a,
  .contact-list li form button {
    /* Use a gap property for spacing between buttons */
    gap: 10px;
    padding: 10px 15px; /* Adjust padding if needed */
    background-color: #333;
    color: #fff;
    text-decoration: none;
    width: 60px; /* Set width for consistent size */
    text-align: center; /* Center text within buttons */
    border: none; /* Remove borders for clean look */
  }
</style>
