@extends('index')

@section('content')
    <section id="contact">
        <h2>Edit Contact</h2>
        <form action="{{ route('contacts.update', $contact->id) }}" method="post">
            @csrf
            @method('PUT')
            <label for="name">Name:</label>
            <input type="text" id="name" name="name" value="{{ $contact->name }}" required><br>

            <label for="email">Email:</label>
            <input type="email" id="email" name="email" value="{{ $contact->email }}" required><br>

            <label for="message">Message:</label>
            <textarea id="message" name="message" rows="5" cols="30" required>{{ $contact->message }}</textarea><br>

            <input type="submit" value="Update Contact">
        </form>
        <p><a href="{{ route('contacts.index') }}">Back to Contacts</a></p>
    </section>
@endsection
