@extends('index')

@section('content')
    <section id="contact">
        <h2>Create New Contact</h2>
        <form action="{{ route('contacts.store') }}" method="post">
            @csrf
            <label for="name">Name:</label>
            <input type="text" id="name" name="name" required><br>

            <label for="email">Email:</label>
            <input type="email" id="email" name="email" required><br>

            <label for="message">Message:</label>
            <textarea id="message" name="message" rows="5" cols="30" required></textarea><br>

            <input type="submit" value="Create Contact">
        </form>
        <p><a href="{{ route('contacts.index') }}">Back to Contacts</a></p>
    </section>
@endsection
