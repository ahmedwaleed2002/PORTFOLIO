@extends('index')

@section('content')
<section id="admin">
    <h2>Admin Dashboard</h2>
    <table>
        <!-- Table header -->
        <thead>
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Email</th>
                <th>Message</th>
                <th>CreatedAt</th>
                <th>Updated At</th>
                <th>Actions</th>
            </tr>
        </thead>
        <!-- Table body -->
        <tbody>
            @foreach ($records as $record)
            <tr>
                <td>{{ $record->id }}</td>
                <td>{{ $record->name }}</td>
                <td>{{ $record->email }}</td>
                <td>{{ $record->message }}</td>
                <td>{{ $record->created_at }}</td>
                <td>{{ $record->updated_at }}</td>
                <td>
                    <a href="{{ route('admin.show', $record->id) }}">Show</a>
                    <a href="{{ route('admin.edit', $record->id) }}">Edit</a>
                    <form action="{{ route('admin.destroy', $record->id) }}" method="post">
                        @csrf
                        @method('DELETE')
                        <button type="submit">Delete</button>
                    </form>
                </td>
            </tr>
            @endforeach
        </tbody>
    </table>
    {{ $records->links() }}
</section>
@endsection
