<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>AHMED WALEED'S PORTFOLIO</title>
    <style>
        /* Internal CSS Styles */
        body {
            font-family: Arial, sans-serif;
            background-color: #f0f0f0;
            color: #333;
            margin: 0;
            padding: 0;
        }
        
        nav {
            background-color: #333;
            color: #fff;
            padding: 10px;
        }
        
        nav ul {
            list-style-type: none;
            margin: 0;
            padding: 0;
        }
        
        nav ul li {
            display: inline;
            margin-right: 10px;
        }
        
        nav ul li a {
            color: #fff;
            text-decoration: none;
        }
        
        h1 {
            text-align: center;
            margin-top: 50px;
        }
        
        p {
            text-align: center;
        }
        
        form {
            width: 50%;
            margin: auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        
        label {
            display: block;
            margin-bottom: 10px;
        }
        
        input[type="text"],
        input[type="email"],
        textarea {
            width: 100%;
            padding: 10px;
            margin-bottom: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
            box-sizing: border-box;
        }
        
        button[type="submit"] {
            width: 100%;
            padding: 10px;
            background-color: #333;
            color: #fff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        
        footer {
            text-align: center;
            margin-top: 50px;
            padding: 20px;
            background-color: #333;
            color: #fff;
        }
    </style>
</head>
<body>
<nav>
  <ul>
    <li><a href="{{ route('home') }}">Home</a></li>
    <li><a href="{{ route('skills') }}">Skills</a></li>
    <li><a href="{{ route('projects') }}">Projects</a></li>
    <li><a href="{{ route('contact') }}">Contact</a></li>

  </ul>
</nav>

<h1>Ahmed Waleed's Portfolio</h1>

<p>Email: <a href="mailto:awby2002@gmail.com">awby2002@gmail.com</a></p>


<p>GitHub: <a href="https://github.com/ahmedwaleed2002" target="_blank">github.com/ahmedwaleed2002</a></p>

@yield('content')

<footer>
    <p>© Ahmed Waleed Bin Yunus. All rights reserved.</p>
</footer>
</body>
</html>
