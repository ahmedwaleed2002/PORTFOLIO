<?php
require_once '../app/Http/Controllers/crud.php';

// Get the form data
$name = $_POST['name'];
$email = $_POST['email'];
$message = $_POST['message'];

// Create a new record
CrudController::create_record($name, $email, $message);

// Send the email
mail('you@example.com', 'New Contact Form Submission', "Name: $name\nEmail: $email\nMessage:\n$message");

// Redirect back to the contact page
header('Location: index.html#contact');
exit;