

<?php $__env->startSection('content'); ?>
    <section id="contact">
        <h2>Contact Me</h2>
        <p>Email: ahmedwaleed@example.com</p>
        <p>GitHub: github.com/ahmedwaleed</p>

        <div>
            <h3>Create New Contact</h3>
            <form action="<?php echo e(route('contacts.store')); ?>" method="post">
                <?php echo csrf_field(); ?>
                <label for="name">Name:</label>
                <input type="text" id="name" name="name" required><br>

                <label for="email">Email:</label>
                <input type="email" id="email" name="email" required><br>

                <label for="message">Message:</label>
                <textarea id="message" name="message" rows="5" cols="30" required></textarea><br>

                <input type="submit" value="Create Contact">
            </form>
        </div>

        <div>
            <h3>Contacts</h3>
            <ul>
                <?php $__currentLoopData = $contacts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contact): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li>
                        <?php echo e($contact->name); ?> - <?php echo e($contact->email); ?> - <?php echo e($contact->message); ?>

                        <a href="<?php echo e(route('contacts.edit', $contact->id)); ?>">Edit</a>
                        <form action="<?php echo e(route('contacts.destroy', $contact->id)); ?>" method="post" style="display: inline;">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit">Delete</button>
                        </form>
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>

        <p><a href="<?php echo e(route('home')); ?>">Go back to the homepage</a></p>
        <p><a href="<?php echo e(route('skills')); ?>">Learn more about my skills</a></p>
        <p><a href="<?php echo e(route('projects')); ?>">Check out my projects</a></p>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('index1', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\awby2\OneDrive\Desktop\portfolio\resources\views/contacts/index1.blade.php ENDPATH**/ ?>