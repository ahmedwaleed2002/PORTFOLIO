

<?php $__env->startSection('content'); ?>
    <section id="contact">
        <h2>Edit Contact</h2>
        <form action="<?php echo e(route('contacts.update', $contact->id)); ?>" method="post">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <label for="name">Name:</label>
            <input type="text" id="name" name="name" value="<?php echo e($contact->name); ?>" required><br>

            <label for="email">Email:</label>
            <input type="email" id="email" name="email" value="<?php echo e($contact->email); ?>" required><br>

            <label for="message">Message:</label>
            <textarea id="message" name="message" rows="5" cols="30" required><?php echo e($contact->message); ?></textarea><br>

            <input type="submit" value="Update Contact">
        </form>
        <p><a href="<?php echo e(route('contacts.index')); ?>">Back to Contacts</a></p>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\awby2\OneDrive\Desktop\portfolio\resources\views/contacts/edit.blade.php ENDPATH**/ ?>