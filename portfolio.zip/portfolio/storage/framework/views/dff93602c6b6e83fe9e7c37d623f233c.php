

<?php $__env->startSection('content'); ?>
<section id="skills">
    <h2>My Skills</h2>
    <ul>
        <?php $__currentLoopData = $skills; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $skill): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($skill); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
    <p><a href="<?php echo e(route('home')); ?>">Go back to the homepage</a></p>
    <p><a href="<?php echo e(route('projects')); ?>">Check out my projects</a></p>
    <p><a href="<?php echo e(route('contact')); ?>">Get in touch</a></p>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\awby2\OneDrive\Desktop\portfolio\resources\views/skills.blade.php ENDPATH**/ ?>