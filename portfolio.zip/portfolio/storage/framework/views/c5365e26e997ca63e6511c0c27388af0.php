

<?php $__env->startSection('content'); ?>
<style>
    /* Styles for the projects section */
    #projects {
        margin-top: 50px;
        padding: 20px;
        background-color: #fff;
        border-radius: 5px;
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    }

    #projects h2 {
        text-align: center;
        margin-bottom: 20px;
    }

    #projects ul {
        list-style-type: none;
        padding: 0;
    }

    #projects li {
        margin-bottom: 30px;
    }

    #projects h3 {
        margin-bottom: 10px;
    }

    #projects p {
        margin-bottom: 15px;
    }

    #projects img {
        display: block;
        margin: 0 auto;
        max-width: 100%;
        height: auto;
        border-radius: 5px;
        box-shadow: 0 0 5px rgba(0, 0, 0, 0.1);
    }
</style>

<section id="projects">
    <h2>My Projects</h2>
    <ul>
        <li>
            <h3>Project 1 - Python Chatbot</h3>
            <p>The Python Chatbot project is a project that aims to create a conversational agent that can interact with users using natural language.</p>
            <!-- Image of Project 1 (if available) -->
            <p>
                <a href="https://github.com/ahmedwaleed2002">
                    <img src="https://th.bing.com/th/id/R.8627053278c97fc1b23f4b25787ad36c?rik=Kq5M6gvMxKudKg&pid=ImgRaw&r=0" alt="Project 1 Image">
                </a>
            </p>
        </li>
        
        <!-- Project 2 -->
        <li>
            <h3>Project 2 - Java Music Player</h3>
            <p>The Java Music Player project is a project that aims to create a simple and user-friendly music player application using Java. The music player will be able to play, pause, stop, and resume audio files in various formats.</p>
            <!-- Image of Project 2 (if available) -->
            <p>
                <a href="https://github.com/ahmedwaleed2002">
                    <img src="https://th.bing.com/th/id/R.27359c66b40e44a3efe132c64b48d173?rik=ooNB3VaMJcdj5A&pid=ImgRaw&r=0" alt="Project 2 Image">
                </a>
            </p>
        </li>
        
        <!-- Project 3 -->
        <li>
            <h3>Project 3 - React Weather App</h3>
            <p>The React Weather App project is a project that aims to create a simple and user-friendly weather app using React. The weather app will be able to display the current weather conditions, temperature, humidity, wind speed, and forecast for any city in the world.</p>
            <!-- Image of Project 3 (if available) -->
            <p>
                <a href="https://github.com/ahmedwaleed2002">
                    <img src="https://th.bing.com/th/id/R.127b470a1814ca2ae06d9f40df34f190?rik=K7lbihz6hujRNA&pid=ImgRaw&r=0" alt="Project 3 Image">
                </a>
            </p>
        </li>
    </ul>
    <p><a href="<?php echo e(route('home')); ?>">Go back to the homepage</a></p>
    <p><a href="<?php echo e(route('skills')); ?>">Learn more about my skills</a></p>
    <p><a href="<?php echo e(route('contact')); ?>">Get in touch</a></p>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\awby2\OneDrive\Desktop\portfolio\resources\views/projects.blade.php ENDPATH**/ ?>